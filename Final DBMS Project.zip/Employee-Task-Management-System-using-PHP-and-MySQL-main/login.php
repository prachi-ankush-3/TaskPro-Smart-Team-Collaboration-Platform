<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Login | Task Pro</title>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="css/style.css">
</head>
<body class="login-body">
	<div class="login-container">
		<div class="login-card">
			<div class="login-header">
				<div class="logo">
					<i class="fa fa-tasks"></i>
					<h1>Task <span>Pro</span></h1>
				</div>
				<p class="login-subtitle">Welcome back! Please sign in to your account.</p>
			</div>

			<form method="POST" action="app/login.php" class="login-form" role="form" aria-label="Login Form">
				<?php if (isset($_GET['error'])) { ?>
					<div class="alert alert-danger" role="alert" aria-live="polite">
						<i class="fa fa-exclamation-circle" aria-hidden="true"></i>
						<span><?php echo stripcslashes($_GET['error']); ?></span>
					</div>
				<?php } ?>

				<?php if (isset($_GET['success'])) { ?>
					<div class="alert alert-success" role="alert" aria-live="polite">
						<i class="fa fa-check-circle" aria-hidden="true"></i>
						<span><?php echo stripcslashes($_GET['success']); ?></span>
					</div>
				<?php } ?>

				<div class="form-group">
					<label for="username" class="form-label">
						<i class="fa fa-user" aria-hidden="true"></i>
						<span>Username</span>
					</label>
					<input type="text" 
						   id="username" 
						   name="user_name" 
						   class="form-input" 
						   placeholder="Enter your username"
						   required
						   autocomplete="username"
						   aria-describedby="username-help"
						   aria-required="true">
					<div class="input-focus-line"></div>
					<div id="username-help" class="sr-only">Enter your username to sign in</div>
				</div>

				<div class="form-group">
					<label for="password" class="form-label">
						<i class="fa fa-lock" aria-hidden="true"></i>
						<span>Password</span>
					</label>
					<input type="password" 
						   id="password" 
						   name="password" 
						   class="form-input" 
						   placeholder="Enter your password"
						   required
						   autocomplete="current-password"
						   aria-describedby="password-help"
						   aria-required="true">
					<div class="input-focus-line"></div>
					<button type="button" 
							class="password-toggle" 
							onclick="togglePassword()"
							aria-label="Toggle password visibility"
							aria-pressed="false">
						<i class="fa fa-eye" id="passwordToggleIcon" aria-hidden="true"></i>
					</button>
					<div id="password-help" class="sr-only">Enter your password to sign in</div>
				</div>

				<button type="submit" class="login-btn" aria-describedby="login-help">
					<span class="btn-text">Sign In</span>
					<span class="btn-loader" aria-hidden="true">
						<i class="fa fa-spinner fa-spin"></i>
					</span>
					<span id="login-help" class="sr-only">Click to sign in to your account</span>
				</button>
			</form>

			<div class="login-footer">
				<p>Don't have an account? <a href="signup.php" class="signup-link">Sign up here</a></p>
			</div>
		</div>

		<div class="login-background">
			<div class="floating-shapes">
				<div class="shape shape-1"></div>
				<div class="shape shape-2"></div>
				<div class="shape shape-3"></div>
				<div class="shape shape-4"></div>
				<div class="shape shape-5"></div>
			</div>
		</div>
	</div>

	<script>
		function togglePassword() {
			const passwordInput = document.getElementById('password');
			const toggleIcon = document.getElementById('passwordToggleIcon');
			const toggleButton = document.querySelector('.password-toggle');
			
			if (passwordInput.type === 'password') {
				passwordInput.type = 'text';
				toggleIcon.classList.remove('fa-eye');
				toggleIcon.classList.add('fa-eye-slash');
				toggleButton.setAttribute('aria-pressed', 'true');
				toggleButton.setAttribute('aria-label', 'Hide password');
			} else {
				passwordInput.type = 'password';
				toggleIcon.classList.remove('fa-eye-slash');
				toggleIcon.classList.add('fa-eye');
				toggleButton.setAttribute('aria-pressed', 'false');
				toggleButton.setAttribute('aria-label', 'Show password');
			}
		}

		document.querySelector('.login-form').addEventListener('submit', function() {
			const submitBtn = document.querySelector('.login-btn');
			const btnText = document.querySelector('.btn-text');
			const btnLoader = document.querySelector('.btn-loader');
			submitBtn.classList.add('loading');
			btnText.style.opacity = '0';
			btnLoader.style.opacity = '1';
		});

		document.querySelectorAll('.form-input').forEach(input => {
			input.addEventListener('focus', function() {
				this.parentElement.classList.add('focused');
			});
			input.addEventListener('blur', function() {
				if (!this.value) {
					this.parentElement.classList.remove('focused');
				}
			});
		});

		const shapes = document.querySelectorAll('.shape');
		shapes.forEach((shape, index) => {
			shape.style.animationDelay = `${index * 0.5}s`;
		});
	</script>
</body>
</html>
