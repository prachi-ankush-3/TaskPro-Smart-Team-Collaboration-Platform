<?php 
session_start();
if (isset($_SESSION['role']) && isset($_SESSION['id'])) {

    if (isset($_POST['id']) && isset($_POST['status']) && $_SESSION['role'] == 'employee') {

        include "../DB_connection.php";

        function validate_input($data) {
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }

        $status = validate_input($_POST['status']);
        $id = validate_input($_POST['id']);   // task_id

        if (empty($status)) {
            $em = "Status is required";
            header("Location: ../edit-task-employee.php?error=$em&id=$id");
            exit();
        } else {

            include "Model/Task.php";

            /** Update task status */
            $data = array($status, $id);
            update_task_status($conn, $data);

            /** -----------------------------------
             * Notify ADMIN when task is completed
             * -----------------------------------*/
          if ($status == "completed") {

    $admin_id = 1; // Admin user id
    $employee_id = $_SESSION['id'];

    // Get employee name
    $emp_sql = "SELECT full_name FROM users WHERE id = ?";
    $emp_stmt = $conn->prepare($emp_sql);
    $emp_stmt->execute([$employee_id]);
    $employee_name = $emp_stmt->fetchColumn();

    // Get task title
    $task_sql = "SELECT title FROM tasks WHERE id = ?";
    $task_stmt = $conn->prepare($task_sql);
    $task_stmt->execute([$id]);
    $task_name = $task_stmt->fetchColumn();

   $task_msg = "✅ $employee_name – $task_name (Completed)";


    // Insert notification
    $sql_notify = "INSERT INTO notifications (recipient, message, type, is_read) 
               VALUES (?, ?, 'Completed✅', 0)";
$stmt_notify = $conn->prepare($sql_notify);
$stmt_notify->execute([$admin_id, $task_msg]);

}


            // Redirect success
            $em = "Task updated successfully";
            header("Location: ../edit-task-employee.php?success=$em&id=$id");
            exit();
        }

    } else {
        $em = "Unknown error occurred";
        header("Location: ../edit-task-employee.php?error=$em");
        exit();
    }

} else { 
    $em = "First login";
    header("Location: ../login.php?error=$em");
    exit();
}
?>
