<?php 
// NOTE: Adjust paths below based on where this file is relative to DB_connection.php
include "../DB_connection.php";
include "Model/Notification.php";

session_start();

if (!isset($_SESSION['role']) || !isset($_SESSION['id'])) {
    // Return empty list or an error message if the user is not logged in
    echo "<li>Please log in to see notifications.</li>";
    exit();
}

// Fetch the notifications for the current user
$notifications = get_unread_notifications($conn, $_SESSION['id']);
notification_make_all_read($conn, $_SESSION['id']);



if (!empty($notifications)) {
    // --- DISPLAY NOTIFICATION LIST ---
    // Only show the first 5 for the dropdown, then a 'View All' link
    $count = 0;
    foreach ($notifications as $notification) {
        if ($count >= 5) break; 
        
        // Add 'read' class based on status for CSS styling
        $status_class = ($notification['is_read'] == 1) ? 'read' : ''; 
        
        // Link points to the controller to mark it as read and redirect
        ?>
        <li class="<?=$status_class?>">
            <a href="notifications.php">
                <!-- <i class="fa fa-info-circle"></i> -->
                <?=htmlspecialchars($notification['message'])?>
            </a>
        </li>
        <?php 
        $count++;
    }
    // Link to the main notifications page
    ?>
    <li>
        <a href="notifications.php" style="justify-content: center; font-weight: 700; color: #3b82f6;">
            View All Notifications
        </a>
    </li>
    <?php
} else {
    // --- DISPLAY ATTRACTIVE EMPTY STATE ---
    ?>
    <li style="border: none; background: none; padding: 0;">
        <div class="notification-bar__empty-state">
            <span class="icon">
                <i class="fa fa-bell-slash-o" aria-hidden="true"></i> 
            </span> 
            <p>You have no new notifications.</p>
            <small>Looks like you're all caught up!</small>
        </div>
    </li>
    <?php
}
?>