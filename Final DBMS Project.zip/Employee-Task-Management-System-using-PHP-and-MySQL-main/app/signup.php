<?php 
session_start();
if (isset($_POST['user_name'], $_POST['password'], $_POST['full_name'], $_POST['email'])) {
	include "../DB_connection.php";
	include_once "Model/User.php";

	function validate_input($data) {
	  return htmlspecialchars(stripslashes(trim($data)));
	}

	$user_name = validate_input($_POST['user_name']);
	$password = validate_input($_POST['password']);
	$full_name = validate_input($_POST['full_name']);
	$email = validate_input($_POST['email']);
	$role = isset($_POST['role']) ? validate_input($_POST['role']) : 'employee';

	// Validate fields
	if (!$user_name) { header("Location: ../signup.php?error=Username is required"); exit();}
	if (!$password) { header("Location: ../signup.php?error=Password is required"); exit();}
	if (!$full_name) { header("Location: ../signup.php?error=Full name is required"); exit();}
	if (!$email) { header("Location: ../signup.php?error=Email is required"); exit();}
	if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { header("Location: ../signup.php?error=Invalid email format"); exit();}
	if (strlen($password) < 6) { header("Location: ../signup.php?error=Password must be at least 6 characters"); exit(); }

	// Check if username exists
	$stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
	$stmt->execute([$user_name]);
	if ($stmt->rowCount() > 0) { header("Location: ../signup.php?error=Username already exists"); exit(); }

	// Check if email exists
	$stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
	$stmt->execute([$email]);
	if ($stmt->rowCount() > 0) { header("Location: ../signup.php?error=Email already exists"); exit(); }

	// Hash password
	$password_hashed = password_hash($password, PASSWORD_DEFAULT);

	// Insert user
	$data = [$full_name, $user_name, $email, $password_hashed, $role];
	insert_user($conn, $data);

	header("Location: ../login.php?success=Account created successfully!");
	exit();
}
?>
