<?php
session_start();
if (isset($_SESSION['role']) && $_SESSION['id'] && $_SESSION['role'] == 'admin') {

    if (isset($_POST['user_name'], $_POST['password'], $_POST['full_name'], $_POST['email'])) {

        include "../DB_connection.php";
        include_once "Model/User.php";

        function validate_input($data) {
            return htmlspecialchars(stripslashes(trim($data)));
        }

        $user_name  = validate_input($_POST['user_name']);
        $password   = password_hash(validate_input($_POST['password']), PASSWORD_DEFAULT);
        $full_name  = validate_input($_POST['full_name']);
        $email      = validate_input($_POST['email']);

        // Validate fields
        if (empty($user_name) || empty($password) || empty($full_name) || empty($email)) {
            $em = "All fields are required";
            header("Location: ../add-user.php?error=$em");
            exit();
        }

        // Correct 5 parameters
        $data = [$full_name, $user_name, $email, $password, "employee"];

        insert_user($conn, $data);

        $sm = "User created successfully";
        header("Location: ../add-user.php?success=$sm");
        exit();

    } else {
        $em = "Unknown error occurred";
        header("Location: ../add-user.php?error=$em");
        exit();
    }

} else {
    $em = "First login";
    header("Location: ../add-user.php?error=$em");
    exit();
}
?>
