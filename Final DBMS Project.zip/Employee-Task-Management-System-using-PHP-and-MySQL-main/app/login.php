<?php 
session_start();

if (isset($_POST['user_name']) && isset($_POST['password'])) {
	include "../DB_connection.php";

	function validate_input($data) {
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		return $data;
	}

	$user_name = validate_input($_POST['user_name']);
	$password = validate_input($_POST['password']);

	if (empty($user_name)) {
		$em = "Username is required";
		header("Location: ../login.php?error=$em");
		exit();
	} else if (empty($password)) {
		$em = "Password is required";
		header("Location: ../login.php?error=$em");
		exit();
	} else {
		$sql = "SELECT * FROM users WHERE username = ?";
		$stmt = $conn->prepare($sql);
		$stmt->execute([$user_name]);

		// ✅ Check if user exists
		if ($stmt->rowCount() == 0) {
			$em = "Account does not exist!";
			header("Location: ../login.php?error=$em");
			exit();
		}

		$user = $stmt->fetch();
		$usernameDb = $user['username'];
		$passwordDb = $user['password'];
		$role = $user['role'];
		$id = $user['id'];

		// ✅ Check password
		if (password_verify($password, $passwordDb)) {
			$_SESSION['role'] = $role;
			$_SESSION['id'] = $id;
			$_SESSION['username'] = $usernameDb;
			header("Location: ../index.php");
			exit();
		} else {
			$em = "Incorrect username or password";
			header("Location: ../login.php?error=$em");
			exit();
		}
	}
} else {
	$em = "Unknown error occurred";
	header("Location: ../login.php?error=$em");
	exit();
}
?>
