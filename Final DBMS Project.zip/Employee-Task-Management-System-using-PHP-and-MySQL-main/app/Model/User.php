<?php
// Prevent redeclaration errors
if (!function_exists('get_all_users')) {

  // Insert a new user
function insert_user($conn, $data) {
    // Include email in SQL if your table has email
    $sql = "INSERT INTO users (full_name, username, email,password, role) VALUES (?, ?,?, ?, ?)";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("Prepare failed: " . implode(", ", $conn->errorInfo()));
    }
    if ($stmt->execute($data)) {
        return true;
    } else {
        die("Insert failed: " . implode(", ", $stmt->errorInfo()));
    }
}


    // Get all users
    function get_all_users($conn) {
        $stmt = $conn->prepare("SELECT * FROM users ORDER BY id DESC");
        $stmt->execute();
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return ($users) ? $users : 0;
    }

    // Get a user by ID
    function get_user_by_id($conn, $id) {
        $sql = "SELECT * FROM users WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$id]);
        return ($stmt->rowCount() > 0) ? $stmt->fetch(PDO::FETCH_ASSOC) : 0;
    }

    // Delete a user by ID
    function delete_user($conn, $id) {
        $sql = "DELETE FROM users WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$id]);
    }
    function update_profile($conn, $data){
    $sql = "UPDATE users SET full_name=?, password=? WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->execute($data);
}


}
?>
