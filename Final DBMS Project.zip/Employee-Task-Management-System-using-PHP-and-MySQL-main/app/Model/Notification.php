<?php  

function get_all_my_notifications($conn, $id){
    $sql = "SELECT * FROM notifications WHERE recipient=? ORDER BY id DESC";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$id]);
    return ($stmt->rowCount() > 0) ? $stmt->fetchAll() : [];
}

function get_unread_notifications($conn, $id){
    $sql = "SELECT * FROM notifications WHERE recipient=? AND is_read=0 ORDER BY id DESC";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$id]);
    return ($stmt->rowCount() > 0) ? $stmt->fetchAll() : [];
}


function count_notification($conn, $id){
	$sql = "SELECT id FROM notifications WHERE recipient=? AND is_read=0";
	$stmt = $conn->prepare($sql);
	$stmt->execute([$id]);

	return $stmt->rowCount();
}

function insert_notification($conn, $data){
	$sql = "INSERT INTO notifications (message, recipient, type) VALUES(?,?,?)";
	$stmt = $conn->prepare($sql);
	$stmt->execute($data);
}

function notification_make_read($conn, $recipient_id, $notification_id){
	$sql = "UPDATE notifications SET is_read=1 WHERE id=? AND recipient=?";
	$stmt = $conn->prepare($sql);
	$stmt->execute([$notification_id, $recipient_id]);
}

// ✅ New function: mark all as read
function notification_make_all_read($conn, $recipient_id){
    $sql = "UPDATE notifications SET is_read=1 WHERE recipient=? AND is_read=0";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$recipient_id]);
}
function delete_all_read_notifications($conn, $recipient_id){
    $sql = "DELETE FROM notifications WHERE recipient=? AND is_read=1";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$recipient_id]);
}

?>
