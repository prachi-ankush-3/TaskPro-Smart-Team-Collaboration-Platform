<header class="header">
    <div class="header-left">
        <h2 class="u-name">
            <i class="fa fa-tasks" aria-hidden="true"></i>
            Task <b>Pro</b>
        </h2>
        <label for="checkbox" class="mobile-menu-toggle">
            <i id="navbtn" class="fa fa-bars" aria-hidden="true"></i>
        </label>
    </div>
    <div class="header-right">
        <div class="notification" id="notificationBtn" title="Notifications">
            <i class="fa fa-bell" aria-hidden="true"></i>
            
            <span id="notificationNum"></span>
        </div>

        <div class="user-profile">
            <span class="user-name">Welcome, <?=$_SESSION['username']?></span>
            <div class="user-role-badge"><?=ucfirst($_SESSION['role'])?></div>
        </div>
    </div>
</header>
<div class="notification-bar" id="notificationBar">
    <ul id="notifications">
        </ul>
</div>

<script src="https://code.jquery.com/jquery-2.2.4.min.js" integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44=" crossorigin="anonymous"></script>

<script type="text/javascript">
    // --- jQuery/AJAX Loader ---
    $(document).ready(function(){
        // Load count and content only once on page load
        $("#notificationNum").load("app/notification-count.php");
        $("#notifications").load("app/notification.php");
    });
    
    // --- Custom JavaScript Toggle ---
    var openNotification = false;
    
    const notification = ()=> {
        let notificationBar = document.querySelector("#notificationBar");
        if (openNotification) {
            notificationBar.classList.remove('open-notification');
            openNotification = false;
        } else {
            notificationBar.classList.add('open-notification');
            openNotification = true;
        }
    }
    
    let notificationBtn = document.querySelector("#notificationBtn");
    notificationBtn.addEventListener("click", notification);

    // Close on outside click
    document.addEventListener('click', function(e) {
        let notificationBar = document.querySelector("#notificationBar");
        let notificationBtn = document.querySelector("#notificationBtn");
        
        if (openNotification && 
            !notificationBar.contains(e.target) && 
            !notificationBtn.contains(e.target)) {
            
            notificationBar.classList.remove('open-notification');
            openNotification = false;
        }
    });
</script>