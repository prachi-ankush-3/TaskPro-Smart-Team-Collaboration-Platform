<?php 
$sName = "localhost";  // Database server is localhost
$uName = "root";   // Database username
$pass = ""; // Database password
$db_name = "task_management_db"; // Database name
try { 
    $conn = new PDO("mysql:host=$sName;dbname=$db_name", $uName, $pass); 
    // Create a database connection using PDO
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); 
    // Set PDO to throw errors if something goes wrong
}catch(PDOException $e){ 
    echo "Connection failed: ". $e->getMessage();
     // Show error message if connection fails
    exit; 
      // Stop the script
}