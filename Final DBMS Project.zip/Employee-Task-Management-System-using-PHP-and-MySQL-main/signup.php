<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Sign Up | Task Pro</title>
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="css/style.css">
</head>
<body class="login-body">
	<div class="login-container">
		<div class="login-card signup-card">
			<div class="login-header">
				<div class="logo">
					<i class="fa fa-user-plus"></i>
					<h1>Join <span>Task Pro</span></h1>
				</div>
				<p class="login-subtitle">Create your account to get started with task management.</p>
			</div>

			<form method="POST" action="app/signup.php" class="login-form" id="signupForm">
				<?php if (isset($_GET['error'])) { ?>
					<div class="alert alert-danger">
						<i class="fa fa-exclamation-circle"></i>
						<?php echo stripcslashes($_GET['error']); ?>
					</div>
				<?php } ?>

				<?php if (isset($_GET['success'])) { ?>
					<div class="alert alert-success">
						<i class="fa fa-check-circle"></i>
						<?php echo stripcslashes($_GET['success']); ?>
					</div>
				<?php } ?>

				<div class="form-row">
					<div class="form-group">
						<label for="fullname" class="form-label">
							<i class="fa fa-user"></i>
							Full Name
						</label>
						<input type="text" 
							   id="fullname" 
							   name="full_name" 
							   class="form-input" 
							   placeholder="Enter your full name"
							   required>
						<div class="input-focus-line"></div>
					</div>
				</div>

				<div class="form-group">
					<label for="username" class="form-label">
						<i class="fa fa-at"></i>
						Username
					</label>
					<input type="text" 
						   id="username" 
						   name="user_name" 
						   class="form-input" 
						   placeholder="Choose a username"
						   required>
					<div class="input-focus-line"></div>
					<div class="input-hint">This will be your login username</div>
				</div>

				<div class="form-group">
					<label for="email" class="form-label">
						<i class="fa fa-envelope"></i>
						Email Address
					</label>
					<input type="email" 
						   id="email" 
						   name="email" 
						   class="form-input" 
						   placeholder="Enter your email address"
						   required>
					<div class="input-focus-line"></div>
				</div>

				<div class="form-group">
					<label for="password" class="form-label">
						<i class="fa fa-lock"></i>
						Password
					</label>
					<input type="password" 
						   id="password" 
						   name="password" 
						   class="form-input" 
						   placeholder="Create a strong password"
						   required>
					<div class="input-focus-line"></div>
					<button type="button" class="password-toggle" onclick="togglePassword('password')">
						<i class="fa fa-eye" id="passwordToggleIcon"></i>
					</button>
					<div class="password-strength">
						<div class="strength-bar">
							<div class="strength-fill" id="strengthFill"></div>
						</div>
						<span class="strength-text" id="strengthText">Password strength</span>
					</div>
				</div>

				<div class="form-group">
					<label for="confirmPassword" class="form-label">
						<i class="fa fa-lock"></i>
						Confirm Password
					</label>
					<input type="password" 
						   id="confirmPassword" 
						   name="confirm_password" 
						   class="form-input" 
						   placeholder="Confirm your password"
						   required>
					<div class="input-focus-line"></div>
					<button type="button" class="password-toggle" onclick="togglePassword('confirmPassword')">
						<i class="fa fa-eye" id="confirmPasswordToggleIcon"></i>
					</button>
				</div>

				<div class="form-group">
					<label for="role" class="form-label">
						<i class="fa fa-briefcase"></i>
						Role
					</label>
					<select id="role" name="role" class="form-input" required>
						<option value="">Select your role</option>
						<option value="employee">Employee</option>
						<option value="admin">Administrator</option>
					</select>
					<div class="input-focus-line"></div>
				</div>

				<div class="form-options">
					<label class="remember-me">
						<input type="checkbox" id="terms" required>
						<span class="checkmark"></span>
						I agree to the <a href="#" class="terms-link">Terms of Service</a> and <a href="#" class="terms-link">Privacy Policy</a>
					</label>
				</div>

				<button type="submit" class="login-btn signup-btn">
					<span class="btn-text">Create Account</span>
					<span class="btn-loader">
						<i class="fa fa-spinner fa-spin"></i>
					</span>
				</button>
			</form>

			<div class="login-footer">
				<p>Already have an account? <a href="login.php" class="signup-link">Sign in here</a></p>
			</div>
		</div>

		<div class="login-background">
			<div class="floating-shapes">
				<div class="shape shape-1"></div>
				<div class="shape shape-2"></div>
				<div class="shape shape-3"></div>
				<div class="shape shape-4"></div>
				<div class="shape shape-5"></div>
				<div class="shape shape-6"></div>
			</div>
		</div>
	</div>

	<script>
		// Password toggle functionality
		function togglePassword(inputId) {
			const passwordInput = document.getElementById(inputId);
			const toggleIcon = document.getElementById(inputId + 'ToggleIcon');
			
			if (passwordInput.type === 'password') {
				passwordInput.type = 'text';
				toggleIcon.classList.remove('fa-eye');
				toggleIcon.classList.add('fa-eye-slash');
			} else {
				passwordInput.type = 'password';
				toggleIcon.classList.remove('fa-eye-slash');
				toggleIcon.classList.add('fa-eye');
			}
		}

		// Password strength checker
		function checkPasswordStrength(password) {
			let strength = 0;
			const strengthFill = document.getElementById('strengthFill');
			const strengthText = document.getElementById('strengthText');
			
			if (password.length >= 8) strength += 1;
			if (/[a-z]/.test(password)) strength += 1;
			if (/[A-Z]/.test(password)) strength += 1;
			if (/[0-9]/.test(password)) strength += 1;
			if (/[^A-Za-z0-9]/.test(password)) strength += 1;
			
			const strengthLevels = ['Very Weak', 'Weak', 'Fair', 'Good', 'Strong'];
			const strengthColors = ['#ef4444', '#f59e0b', '#eab308', '#22c55e', '#16a34a'];
			
			strengthFill.style.width = (strength * 20) + '%';
			strengthFill.style.backgroundColor = strengthColors[strength - 1] || '#ef4444';
			strengthText.textContent = strengthLevels[strength - 1] || 'Very Weak';
			strengthText.style.color = strengthColors[strength - 1] || '#ef4444';
		}

		// Password confirmation validation
		function validatePasswordMatch() {
			const password = document.getElementById('password').value;
			const confirmPassword = document.getElementById('confirmPassword').value;
			const confirmInput = document.getElementById('confirmPassword');
			
			if (confirmPassword && password !== confirmPassword) {
				confirmInput.style.borderColor = '#ef4444';
				return false;
			} else {
				confirmInput.style.borderColor = 'rgba(226, 232, 240, 0.8)';
				return true;
			}
		}

		// Event listeners
		document.getElementById('password').addEventListener('input', function() {
			checkPasswordStrength(this.value);
			validatePasswordMatch();
		});

		document.getElementById('confirmPassword').addEventListener('input', validatePasswordMatch);

		// Form submission with validation
		document.getElementById('signupForm').addEventListener('submit', function(e) {
			if (!validatePasswordMatch()) {
				e.preventDefault();
				alert('Passwords do not match!');
				return;
			}
			
			const submitBtn = document.querySelector('.signup-btn');
			const btnText = document.querySelector('.btn-text');
			const btnLoader = document.querySelector('.btn-loader');
			
			submitBtn.classList.add('loading');
			btnText.style.opacity = '0';
			btnLoader.style.opacity = '1';
		});

		// Input focus effects
		document.querySelectorAll('.form-input').forEach(input => {
			input.addEventListener('focus', function() {
				this.parentElement.classList.add('focused');
			});
			
			input.addEventListener('blur', function() {
				if (!this.value) {
					this.parentElement.classList.remove('focused');
				}
			});
		});

		// Floating shapes animation
		const shapes = document.querySelectorAll('.shape');
		shapes.forEach((shape, index) => {
			shape.style.animationDelay = `${index * 0.3}s`;
		});
	</script>
</body>
</html>
