<?php 
session_start();
if (isset($_SESSION['role']) && isset($_SESSION['id']) ) {

	 include "DB_connection.php";
    include "app/Model/Task.php";
    include "app/Model/User.php";

	if ($_SESSION['role'] == "admin") {
		  $todaydue_task = count_tasks_due_today($conn);
	     $overdue_task = count_tasks_overdue($conn);
	     $nodeadline_task = count_tasks_NoDeadline($conn);
	     $num_task = count_tasks($conn);
	     $num_users = count_users($conn);
	     $pending = count_pending_tasks($conn);
	     $in_progress = count_in_progress_tasks($conn);
	     $completed = count_completed_tasks($conn);
	}else {
        $num_my_task = count_my_tasks($conn, $_SESSION['id']);
        $overdue_task = count_my_tasks_overdue($conn, $_SESSION['id']);
        $nodeadline_task = count_my_tasks_NoDeadline($conn, $_SESSION['id']);
        $pending = count_my_pending_tasks($conn, $_SESSION['id']);
	    $in_progress = count_my_in_progress_tasks($conn, $_SESSION['id']);
	    $completed = count_my_completed_tasks($conn, $_SESSION['id']);

	}
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Task Pro - Dashboard</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="css/style.css">
</head>
<body>
	<input type="checkbox" id="checkbox">
	<?php include "inc/header.php" ?>
	<div class="body">
		<?php include "inc/nav.php" ?>
		<section class="section-1">
			<div class="page-header">
				<h1 class="page-title">
					<i class="fa fa-tachometer" aria-hidden="true"></i>
					Dashboard Overview
				</h1>
				<p class="page-subtitle">Welcome back! Here's what's happening with your tasks today.</p>
			</div>

			<?php if ($_SESSION['role'] == "admin") { ?>
				<div class="dashboard">
					<div class="dashboard-item">
						<div class="dashboard-icon">
							<i class="fa fa-users"></i>
						</div>
						<div class="dashboard-content">
							<h3><?=$num_users?></h3>
							<span>Total Employees</span>
						</div>
					</div>
					<div class="dashboard-item">
						<div class="dashboard-icon">
							<i class="fa fa-tasks"></i>
						</div>
						<div class="dashboard-content">
							<h3><?=$num_task?></h3>
							<span>All Tasks</span>
						</div>
					</div>
					<div class="dashboard-item urgent">
						<div class="dashboard-icon">
							<i class="fa fa-window-close-o"></i>
						</div>
						<div class="dashboard-content">
							<h3><?=$overdue_task?></h3>
							<span>Overdue Tasks</span>
						</div>
					</div>
					<div class="dashboard-item">
						<div class="dashboard-icon">
							<i class="fa fa-clock-o"></i>
						</div>
						<div class="dashboard-content">
							<h3><?=$nodeadline_task?></h3>
							<span>No Deadline</span>
						</div>
					</div>
					<div class="dashboard-item warning">
						<div class="dashboard-icon">
							<i class="fa fa-exclamation-triangle"></i>
						</div>
						<div class="dashboard-content">
							<h3><?=$todaydue_task?></h3>
							<span>Due Today</span>
						</div>
					</div>
					<div class="dashboard-item">
						<div class="dashboard-icon">
							<i class="fa fa-bell"></i>
						</div>
						<div class="dashboard-content">
							<h3><?=$overdue_task?></h3>
							<span>Notifications</span>
						</div>
					</div>
					<div class="dashboard-item">
						<div class="dashboard-icon">
							<i class="fa fa-square-o"></i>
						</div>
						<div class="dashboard-content">
							<h3><?=$pending?></h3>
							<span>Pending</span>
						</div>
					</div>
					<div class="dashboard-item">
						<div class="dashboard-icon">
							<i class="fa fa-spinner"></i>
						</div>
						<div class="dashboard-content">
							<h3><?=$in_progress?></h3>
							<span>In Progress</span>
						</div>
					</div>
					<div class="dashboard-item success">
						<div class="dashboard-icon">
							<i class="fa fa-check-square-o"></i>
						</div>
						<div class="dashboard-content">
							<h3><?=$completed?></h3>
							<span>Completed</span>
						</div>
					</div>
				</div>
			<?php }else{ ?>
				<div class="dashboard">
					<div class="dashboard-item">
						<div class="dashboard-icon">
							<i class="fa fa-tasks"></i>
						</div>
						<div class="dashboard-content">
							<h3><?=$num_my_task?></h3>
							<span>My Tasks</span>
						</div>
					</div>
					<div class="dashboard-item urgent">
						<div class="dashboard-icon">
							<i class="fa fa-window-close-o"></i>
						</div>
						<div class="dashboard-content">
							<h3><?=$overdue_task?></h3>
							<span>Overdue</span>
						</div>
					</div>
					<div class="dashboard-item">
						<div class="dashboard-icon">
							<i class="fa fa-clock-o"></i>
						</div>
						<div class="dashboard-content">
							<h3><?=$nodeadline_task?></h3>
							<span>No Deadline</span>
						</div>
					</div>
					<div class="dashboard-item">
						<div class="dashboard-icon">
							<i class="fa fa-square-o"></i>
						</div>
						<div class="dashboard-content">
							<h3><?=$pending?></h3>
							<span>Pending</span>
						</div>
					</div>
					<div class="dashboard-item">
						<div class="dashboard-icon">
							<i class="fa fa-spinner"></i>
						</div>
						<div class="dashboard-content">
							<h3><?=$in_progress?></h3>
							<span>In Progress</span>
						</div>
					</div>
					<div class="dashboard-item success">
						<div class="dashboard-icon">
							<i class="fa fa-check-square-o"></i>
						</div>
						<div class="dashboard-content">
							<h3><?=$completed?></h3>
							<span>Completed</span>
						</div>
					</div>
				</div>
			<?php } ?>

			<div class="quick-actions">
				<h2 class="section-title">Quick Actions</h2>
				<div class="action-buttons">
					<?php if ($_SESSION['role'] == "admin") { ?>
						<a href="create_task.php" class="action-btn primary">
							<i class="fa fa-plus"></i>
							<span>Create New Task</span>
						</a>
						<a href="user.php" class="action-btn secondary">
							<i class="fa fa-users"></i>
							<span>Manage Users</span>
						</a>
						<a href="tasks.php" class="action-btn tertiary">
							<i class="fa fa-tasks"></i>
							<span>View All Tasks</span>
						</a>
					<?php } else { ?>
						<a href="my_task.php" class="action-btn primary">
							<i class="fa fa-tasks"></i>
							<span>View My Tasks</span>
						</a>
						<a href="profile.php" class="action-btn secondary">
							<i class="fa fa-user"></i>
							<span>Update Profile</span>
						</a>
						<a href="notifications.php" class="action-btn tertiary">
							<i class="fa fa-bell"></i>
							<span>Notifications</span>
						</a>
					<?php } ?>
				</div>
			</div>
		</section>
	</div>

<script type="text/javascript">
	var active = document.querySelector("#navList li:nth-child(1)");
	active.classList.add("active");
</script>
</body>
</html>
<?php }else{ 
   $em = "First login";
   header("Location: login.php?error=$em");
   exit();
}
 ?>

 <?php
// Count total users
function count_users($conn){
    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM users");
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row['total'];
}
?>
